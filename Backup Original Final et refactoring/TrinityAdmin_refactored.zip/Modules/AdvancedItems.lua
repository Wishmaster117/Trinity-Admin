-- ─────────────────────────────────────────────────────────
--  En-tête standard des modules TrinityAdmin
-- ─────────────────────────────────────────────────────────
local addonName, TA = ...           -- table privée transmise par le core
local TrinityAdmin  = TA            -- alias court pour l’addon
local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local AdvancedItems = TrinityAdmin:GetModule("AdvancedItems")
print("[DEBUG] AdvancedItems =", AdvancedItems)

function AdvancedItems:OnShow()
     print("[DEBUG] AdvancedItems:OnShow appelé")
    TrinityAdmin:LoadDataChunk("Items1")
    TrinityAdmin:LoadDataChunk("Items2")
    TrinityAdmin:LoadDataChunk("Items3")
end

local currentResults = nil
local isFiltered   = false

-- Fonction pour afficher le panneau AdvancedItems
function AdvancedItems:ShowAdvancedItemsPanel()
    TrinityAdmin:LoadDataChunk("Items1")
    TrinityAdmin:LoadDataChunk("Items2")
    TrinityAdmin:LoadDataChunk("Items3")

    TrinityAdmin:HideMainMenu()
    if not self.panel then
        self:CreateAdvancedItemsPanel()
    end
    self.panel:Show()
end

------------------------------------------------------------
-- Items Advanced ADD
------------------------------------------------------------
local function LoadItemsChunk(startIndex, numLines)
    local src   = TA.ItemsData
    local chunk = {}
    for i = startIndex, math.min(startIndex + numLines - 1, #src) do
        chunk[#chunk+1] = src[i]
    end
    return chunk
end

------------------------------------------------------------
-- Création du panneau AdvancedItems
------------------------------------------------------------
function AdvancedItems:CreateAdvancedItemsPanel()
    local panel = CreateFrame("Frame", "TrinityAdminServerAdminPanel", TrinityAdminMainFrame)
    panel:ClearAllPoints()
    panel:SetPoint("TOPLEFT", TrinityAdminMainFrame, "TOPLEFT", 10, -50)
    panel:SetPoint("BOTTOMRIGHT", TrinityAdminMainFrame, "BOTTOMRIGHT", -10, 10)

    local bg = panel:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(true)
    bg:SetColorTexture(0.2, 0.2, 0.5, 0.7)

    panel.title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    panel.title:SetPoint("TOPLEFT", 10, -10)
    panel.title:SetText(L["Advance Items Panel"])

    ------------------------------------------------------------
    -- Variables
    ------------------------------------------------------------
    local entriesPerPage = 100
    local currentPage   = 1
    local currentOptions = {} 

    ------------------------------------------------------------
    -- Fonctions utilitaires
    ------------------------------------------------------------
    local function Data()
        return TA.ItemsData or {}
    end

    local function LoadItemsChunk(startIndex, numLines)
        local src   = Data()
        local chunk = {}
        for i = startIndex, math.min(startIndex + numLines - 1, #src) do
            chunk[#chunk+1] = src[i]
        end
        print("[AdvancedItems] LoadItemsChunk →", #chunk, "lignes")
        return chunk
    end

    local function TotalItems()
        return #Data()
    end

    ------------------------------------------------------------
    -- Zones de saisie (recherche, etc.)
    ------------------------------------------------------------
    local advancedLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    advancedLabel:SetPoint("TOP", panel, "TOP", 0, -20)
    advancedLabel:SetText(L["Add Items Advanced"])

    local filterEditBox = CreateFrame("EditBox", "TrinityAdminGOFilterEditBox", panel, "InputBoxTemplate")
    filterEditBox:SetPoint("TOP", advancedLabel, "BOTTOM", 0, -5)
    filterEditBox:SetText(L["Search..."])
    TrinityAdmin.AutoSize(filterEditBox, 20, 13, nil, 200)

    local playerNameEditBox = CreateFrame("EditBox", "TrinityAdminPlayerNameEditBox", panel, "InputBoxTemplate")
    playerNameEditBox:SetPoint("LEFT", filterEditBox, "RIGHT", 10, 0)
    playerNameEditBox:SetText(L["Player Name"])
    TrinityAdmin.AutoSize(playerNameEditBox, 20, 13, nil, 120)

    local howMuchEditBox = CreateFrame("EditBox", "TrinityAdminHowMuchEditBox", panel, "InputBoxTemplate")
    howMuchEditBox:SetPoint("LEFT", playerNameEditBox, "RIGHT", 10, 0)
    howMuchEditBox:SetText(L["HowMuch"])
    TrinityAdmin.AutoSize(howMuchEditBox, 20, 13)

    ------------------------------------------------------------
    -- ScrollFrame et scrollChild
    ------------------------------------------------------------
    local scrollFrame = CreateFrame("ScrollFrame", "TrinityAdminGOScrollFrame", panel, "UIPanelScrollFrameTemplate")
    scrollFrame:SetSize(220, 200)
    scrollFrame:SetPoint("TOPRIGHT", filterEditBox, "BOTTOMRIGHT", 5, -5)
    scrollFrame:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -30, 50)

    local scrollChild = CreateFrame("Frame", "TrinityAdminGOScrollChild", scrollFrame)
    scrollChild:SetSize(220, 400)
    scrollFrame:SetScrollChild(scrollChild)

    ------------------------------------------------------------
    -- Boutons de pagination
    ------------------------------------------------------------
    local btnPrev = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnPrev:SetText(L["Pagination_Preview"])
    TrinityAdmin.AutoSize(btnPrev, 20, 16)
    btnPrev:SetPoint("BOTTOM", panel, "BOTTOM", -120, 10)

    local btnNext = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnNext:SetText(L["Next"])
    TrinityAdmin.AutoSize(btnNext, 20, 16)
    btnNext:SetPoint("BOTTOM", panel, "BOTTOM", 60, 10)

    local btnPage = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnPage:SetPoint("BOTTOM", panel, "BOTTOM", -30, 10)
    btnPage:SetText("Page 1 / 1")
    TrinityAdmin.AutoSize(btnPage, 20, 16)

    ------------------------------------------------------------
    -- Fonction PopulateGOScroll (affichage du chunk actuel)
    ------------------------------------------------------------
    local function PopulateGOScroll(data)
        local sourceData, totalEntriesLocal

        if data then
            sourceData = data
            totalEntriesLocal = #data
            isFiltered = true
        else
            totalEntriesLocal = TotalItems()
            sourceData = LoadItemsChunk((currentPage - 1) * entriesPerPage + 1, entriesPerPage)
            isFiltered = false
        end

        if scrollChild.buttons then
            for _, btn in ipairs(scrollChild.buttons) do
                btn:Hide()
            end
        else
            scrollChild.buttons = {}
        end

        local optionsChunk = {}

        if isFiltered then
            local startIdx = (currentPage - 1) * entriesPerPage + 1
            local endIdx   = math.min(currentPage * entriesPerPage, totalEntriesLocal)
            for i = startIdx, endIdx do
                if sourceData[i] then
                    table.insert(optionsChunk, sourceData[i])
                end
            end
        else
            optionsChunk = sourceData
        end

        print("[DEBUG] optionsChunk size =", #optionsChunk, "isFiltered =", isFiltered)

        if #optionsChunk == 0 then
            if not scrollChild.noResultText then
                scrollChild.noResultText = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                scrollChild.noResultText:SetPoint("TOP", scrollChild, "TOP", 0, -10)
                scrollChild.noResultText:SetText("|cffff0000Nothing found|r")
            end
            scrollChild.noResultText:Show()
            scrollChild:SetHeight(50)
            btnPrev:SetEnabled(false)
            btnNext:SetEnabled(false)
            btnPage:SetText("Page 0 / 0")
            return
        else
            if scrollChild.noResultText then
                scrollChild.noResultText:Hide()
            end
        end

        local lastButton = nil
        for i, option in ipairs(optionsChunk) do
            local btn = scrollChild.buttons[i]
            if not btn then
                btn = CreateFrame("Button", nil, scrollChild, "UIPanelButtonTemplate")
                btn:SetSize(200, 20)
                table.insert(scrollChild.buttons, btn)
            end
            btn:Show()

            if not lastButton then
                btn:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 10, -10)
            else
                btn:SetPoint("TOPLEFT", lastButton, "BOTTOMLEFT", 0, -5)
            end

            local fullText = option.name or ("Item " .. i)
            local truncatedText = fullText
            if #fullText > 20 then
                truncatedText = fullText:sub(1, 20) .. "..."
            end
            btn:SetText(truncatedText)

            btn:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                if option.entry then
                    local link = "|cffffffff|Hitem:" .. option.entry .. "|h[" .. (option.name or "Item") .. "]|h|r"
                    GameTooltip:SetHyperlink(link)
                else
                    GameTooltip:SetText(fullText, 1, 1, 1, 1, true)
                end
                GameTooltip:Show()
            end)
            btn:SetScript("OnLeave", function(self)
                GameTooltip:Hide()
            end)

            btn:SetScript("OnClick", function()
                local playerName = playerNameEditBox:GetText()
                local howMuch    = howMuchEditBox:GetText()
                local command    = ""

                if playerName == L["Player Name"] or playerName == "" then
                    if howMuch == "" or howMuch == "HowMuch?" then
                        command = ".additem " .. option.entry
                    else
                        command = ".additem " .. option.entry .. " " .. howMuch
                    end
                else
                    if howMuch == "" or howMuch == "HowMuch?" then
                        command = ".additem to " .. playerName .. " " .. option.entry
                    else
                        command = ".additem to " .. playerName .. " " .. option.entry .. " " .. howMuch
                    end
                end

                print("Commande envoyée :", command)
                TrinityAdmin:SendCommand(command)
            end)

            lastButton = btn
        end

        local visibleCount = #optionsChunk
        local contentHeight = (visibleCount * 25) + 10
        scrollChild:SetHeight(contentHeight)

        btnPage:SetText(currentPage .. " / " .. math.ceil(totalEntriesLocal / entriesPerPage))
        btnPrev:SetEnabled(currentPage > 1)
        btnNext:SetEnabled(currentPage < math.ceil(totalEntriesLocal / entriesPerPage))
    end

    ------------------------------------------------------------
    -- Boutons de pagination
    ------------------------------------------------------------
    btnPrev:SetScript("OnClick", function()
        if currentPage > 1 then
            currentPage = currentPage - 1
            if isFiltered then
                PopulateGOScroll(currentResults)
            else
                PopulateGOScroll()
            end
        end
    end)

    btnNext:SetScript("OnClick", function()
        local totalPagesCalc
        if isFiltered then
            totalPagesCalc = math.ceil(#currentResults / entriesPerPage)
        else
            totalPagesCalc = math.ceil(TotalItems() / entriesPerPage)
        end

        if currentPage < totalPagesCalc then
            currentPage = currentPage + 1
            if isFiltered then
                PopulateGOScroll(currentResults)
            else
                PopulateGOScroll()
            end
        end
    end)

    ------------------------------------------------------------
    -- Remplissage initial (sans filtre)
    ------------------------------------------------------------
    PopulateGOScroll()

    ------------------------------------------------------------
    -- Recherche
    ------------------------------------------------------------
	local function SearchItems(search)
		local results = {}
		-- on enlève les accents et on passe en minuscules
		local normalizedSearch = TA.RemoveAccents(search:lower())
	
		for _, entry in ipairs(TA.ItemsData or {}) do
			if (entry.normalizedName and entry.normalizedName:find(normalizedSearch, 1, true))
			or tostring(entry.entry) == search
			then
				table.insert(results, entry)
			end
		end
		return results
	end

    filterEditBox:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
        local searchText = self:GetText():lower()

        if searchText == L["Search..."] or #searchText < 3 then
            TrinityAdmin:Print(L["Please enter au moins 3 caractères pour la recherche."])
            return
        end

        currentPage    = 1
        currentResults = SearchItems(searchText) or {}
        isFiltered     = true
        PopulateGOScroll(currentResults)
    end)

    ------------------------------------------------------------
    -- Bouton Reset
    ------------------------------------------------------------
    local btnReset = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnReset:SetText(L["Reset"])
    TrinityAdmin.AutoSize(btnReset, 20, 16)
    btnReset:SetPoint("RIGHT", filterEditBox, "RIGHT", -210, 0)
    btnReset:SetScript("OnClick", function()
        filterEditBox:SetText(L["Search..."])
		playerNameEditBox:SetText(L["Player Name"])
		howMuchEditBox:SetText(L["HowMuch"])
        currentPage    = 1
        isFiltered     = false
        currentResults = nil
        PopulateGOScroll()
    end)

    --------------------------------------------------------
    -- Bouton Back
    --------------------------------------------------------
    local btnBack = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btnBack:SetText(L["Back"])
    TrinityAdmin.AutoSize(btnBack, 20, 16)
    btnBack:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 10, 10)
    btnBack:SetScript("OnClick", function()
        panel:Hide()
        TrinityAdmin:ShowMainMenu()
    end)

    self.panel = panel
end
