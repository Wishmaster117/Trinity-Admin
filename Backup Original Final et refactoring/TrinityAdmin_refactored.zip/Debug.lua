function TrinityAdmin:DumpLeakedGlobals()
    local white = { _G = true, TrinityAdmin = true }   -- gardez si nécessaire
    for k in pairs(_G) do
        if not white[k] then
            print("|cffff0000[GLOB]|r", k)
        end
    end
end